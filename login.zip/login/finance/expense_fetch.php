<?php 

try {
	include "../includes/finance_db_connect.php";

	function expense($pdo) {
		$query = "SELECT * FROM expenses";
		$stmt = $pdo->prepare($query);
		$stmt->execute();
		return $stmt->rowCount();
	}

} catch(PDOException $e) {
	die("query Failed" . $e->getMessage());
	
}

try {

	function tax($pdo) {
		$query = "SELECT * FROM tax";
		$stmt = $pdo->prepare($query);
		$stmt->execute();
		return $stmt->rowCount();
	}

} catch(PDOException $e) {
	die("query Failed" . $e->getMessage());
	
}