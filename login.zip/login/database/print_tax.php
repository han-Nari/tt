<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";
	require_once "tax_db_fetch.php";
	require_once "delete.php";

	$admin_id = $_SESSION['email'];

	if (!isset($admin_id)) {
	    header('location:../login.php');
	}
	
	if (!isset($_SESSION["passCode"])) {
	    header('location: database.php');
	    exit;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Save Tax</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "../table/table.css"; ?>
		@media print {
    thead { display: table-header-group; }
    tr, td {
        page-break-inside: avoid;
    }
    table {
        page-break-after: auto;
    }
}

	</style>
</head>
<body>
	<main>
	<!-- Main content -->
		<section class="full">
			<div class="container">
				<div class="auto">
					<table id="largeTable">
						<caption>
							<div class="flexible">
								<h1 class="title">Tax Database</h1>
								<div class="print">
									<i onclick="window.print()" class="fa-solid fa-print"></i>
								</div>
							</div>
						</caption>
						<thead>
							<tr>
								<th>No</th>
								<th>Assesses Value</th>
								<th>Basic Tax</th>
								<th>Sef</th>
								<th>Total Tax</th>
								<th>Date</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($results as $result) : ?>
								<tr>
									<td data-cell="No"><?php echo $result["id"]; ?></td>
									<td data-cell="Assesses Value"><?php echo $result["assessed_value"]; ?></td>
									<td data-cell="Basic Tax"><?php echo $result["basic_tax"]; ?></td>
									<td data-cell="Sef"><?php echo $result["sef"]; ?></td>
									<td data-cell="Total Tax"><?php echo $result["total_tax"]; ?></td>
									<td data-cell="Date"><?php echo $result["created_at"]; ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>	
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
</body>
</html>



	