<?php 

$error = array("passCode" => "");
// Initialize a variable to determine whether the form was submitted correctly.
$formSubmitted = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Here, you'd process your form, e.g., validate inputs and save data to a database.
    try {
		function dataInput($data) {
    	   $data = trim($data);
      	   $data = stripslashes($data);
      	   $data = htmlspecialchars($data);
           return $data;
        }

        $passCode = dataInput($_POST["password"]);

        $query = $pdo->prepare("SELECT * FROM code WHERE passcode = :passcode");
        $query->bindParam(":passcode", $passCode, PDO::PARAM_STR);
        $query->execute();
        $result = $query->fetch(PDO::FETCH_ASSOC);

	        if(!$result) {
	             $error["passCode"] = "Invalid Password";
	          } else {
	          	// If everything is correct and the form is processed successfully:
	          	 $_SESSION["passCode"] = $passCode;
	          	 $formSubmitted = true;
	        }
		} catch(PDOException $e) {
	      die("Connection failed" . $e->getMessage());
	   }
 
}
?>