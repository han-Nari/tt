<?php 
try {   
    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['cpass'])) {
        // Retrieve the password from the form
        $password = $_POST['passc'];

        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Prepare an insert statement
        $sql = "INSERT INTO code (passcode) VALUES (:password)";

        // Prepare the statement
        $stmt = $pdo->prepare($sql);

        // Bind the parameter
        $stmt->bindParam(':password', $hashedPassword, PDO::PARAM_STR);

        // Execute the statement
        if ($stmt->execute()) {
            header("location:admins.php");
        } else {
            echo "Failed to set the password.";
        }
    }
} catch (PDOException $e) {
    // Catch and display the error
    die("Could not connect to the database" . $e->getMessage());
}
?>