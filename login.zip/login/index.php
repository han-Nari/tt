<!DOCTYPE html>
<html>
<head>
    <title>Responsive Searchable Table</title>
    <link rel="stylesheet" type="text/css" href="style.css">

    <style>
        body {
    font-family: Arial, sans-serif;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table, th, td {
    border: 1px solid black;
}

th, td {
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

/* Responsive table */
@media screen and (max-width: 600px) {
    table, thead, tbody, th, td, tr {
        display: block;
    }

    thead tr {
        position: absolute;
        top: -9999px;
        left: -9999px;
    }

    tr { border: 1px solid #ccc; }

    td {
        border: none;
        border-bottom: 1px solid #eee;
        position: relative;
        padding-left: 50%;
    }

    td:before {
        /* Now like a table header */
        position: absolute;
        /* Top/left values mimic padding */
        top: 6px;
        left: 6px;
        width: 45%;
        padding-right: 10px;
        white-space: nowrap;
        content: attr(data-title);
    }
}

    </style>
</head>
<body>

<input type="text" id="searchInput" onkeyup="searchTable()" placeholder="Search for names..">

<table id="infoTable">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Country</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>John Doe</td>
            <td>johndoe@example.com</td>
            <td>USA</td>
        </tr>
        <tr>
            <td>Jane Doe</td>
            <td>janedoe@example.com</td>
            <td>Canada</td>
        </tr>
        <!-- Add more rows as needed -->
    </tbody>
</table>

<script>
    function searchTable() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("infoTable");
    tr = table.getElementsByTagName("tr");

    // Loop through all table rows, and hide those who don't match the search query
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td");
        for (var j = 0; j < td.length; j++) {
            if (td[j]) {
                txtValue = td[j].textContent || td[j].innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                    break; // Stop this loop, and go to next row
                } else {
                    tr[i].style.display = "none";
                }
            }       
        }
    }
}

</script>
</body>
</html>
