let activePage = window.location.pathname;
let navLinks = document.querySelectorAll('a');

navLinks.forEach(item => {
    if(item.href.includes(`${activePage}`)) {
        item.classList.add('active');
    }
});

let navBtn = document.querySelector('.bar');
let sideBar = document.querySelector('nav');
let ul = document.querySelector('ul');
let changeIcon = document.querySelector('.fa-bars');
let main = document.querySelector('main');

navBtn.addEventListener('click', () => {
    main.classList.toggle('slide');
});

let closed = document.querySelector('.closed');
    closed.addEventListener('click', ()=> {
    main.classList.remove('slide');
});

let x = document.querySelector('.remove');
    x.addEventListener('click', ()=> {
    document.querySelector('.update, .data, .sub').remove("closed");
});

let modi = document.querySelector('.edit');
let mark = document.querySelector(".cls");
let edit = document.querySelector('.edits');

    mark.addEventListener("click", () => {
        edit.style.display = "block";
    });

    modi.addEventListener('click', () => {
        edit.style.display = "block";
    });


function searchTable() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("infoTable");
    tr = table.getElementsByTagName("tr");

    // Loop through all table rows, and hide those who don't match the search query
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td");
        for (var j = 0; j < td.length; j++) {
            if (td[j]) {
                txtValue = td[j].textContent || td[j].innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                    break; // Stop this loop, and go to next row
                } else {
                    tr[i].style.display = "none";
                }
            }       
        }
    }
}