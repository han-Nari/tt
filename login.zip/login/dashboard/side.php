<?php
  $select_username = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
  $select_username->execute([$admin_id]);
  $fetch_username = $select_username->fetch(PDO::FETCH_ASSOC);
?>

<nav>
    <div class="logo">
        <div class="logos">
           <img src="../img/logo.png">
           <span class="town">Towntech Innvation</span>
        </div>
        <i class="fa-solid fa-times closed"></i>
    </div>
    <ul>
        <div class="ava">
           <img class="avatar big" name="old_file" src="../uploads/<?php echo $fetch_username["profile"] ?>">
            <div class="user">
                 <p><?php echo $fetch_username['username'];?></p>
             </div> 
        </div>
        <span class="opac">Main</span>
        <li>
            <a href="../dashboard/dash.php">
                <span class="icon"><i class="fa-solid fa-cube"></i></span>
                <span class="text">Dashboard</span>
            </a>
        </li>
        <span class="opac">Admin</span>
        <li>
            <a href="../admins/admins.php">
                <span class="icon"><i class="fa-solid fa-user-tie"></i></span>
                <span class="text">Admin</span>
            </a>
        </li>
        <!-- Financial Management -->
        <span class="opac">Finance</span>
        <li>
            <a href="../finance/expense.php">
                <span class="icon"><i class="fa-solid fa-money-bill-trend-up"></i></span>
                <span class="text">Expenses Management</span>
            </a>
        </li>
         <li>
            <a href="../finance/income.php">
                <span class="icon"><i class="fa-solid fa-coins"></i></span>
                <span class="text">Income Management</span>
            </a>
        </li>
        <!-- Real Property Tax -->
        <span class="opac">Real Property Tax</span>
        <li>
            <a href="../rpt/tax.php">
                <span class="icon"><i class="fa-solid fa-money-bill"></i></span>
                <span class="text">Tax</span>
            </a>
        </li>
        <span class="opac">Database</span>
        <li>
            <a href="../database/database.php" class="right">
                <span class="icon"><i class="fa-solid fa-database"></i></span>
                <span class="text">Database</span>
            </a>
        </li>
        <span class="opac">Logout</span>
        <li>
            <a href="logout.php">
                <span class="icon"><i class="fa-solid fa-arrow-right-from-bracket"></i></span>
                <span class="text">Logout</span>
            </a>
        </li>
    </ul>
</nav>


