<header>
	<div class="sidebar">
		<div class="bar">
			<i class="fa-solid fa-bars"></i>
		</div>
		<h1  class="title none">Group 69 (LGU)</h1>
	</div>
	<div class="icons">
		<div class="out">
			 <img class="avatar" src="../uploads/<?php echo $fetch_username["profile"] ?>">
		</div>
		<!-- <i class="fa-solid fa-bell"></i> -->
	</div>
</header>


