<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";
	require_once "save_tax.php";

	$admin_id = $_SESSION['email'];

	if (!isset($admin_id)) {
	    header('location:../login.php');
	}

	unset($_SESSION["passCode"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Real Property Tax Calculator</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "tax.css"; ?>
		<?php include "../table/table.css" ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section class="taxes">
			<?php if(isset($_SESSION['success_message'])) : ?>
				<div class="sub">
					<strong><?php echo $_SESSION['success_message'];?></strong>
					<i class="fa-solid fa-xmark remove"></i>
				</div>
				<?php unset($_SESSION['success_message']); ?>
			<?php endif; ?>
			<form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">	
			    <h1 class="tax">Real Property Tax Calculator</h1>
			    <label for="propertyValue">Property Value:</label>
			    <input type="number" id="propertyValue" name="propertyValue" placeholder="Property Value" required>

			    <label for="propertyType">Property Type</label>
			    <select id="propertyType" name="propertyType" required>
			        <option value="Residential">Residential(20%)</option>
			        <option value="Commercial">Commercial(50%)</option>
			        <option value="Agricultural">Agricultural(40%)</option>
			        <option value="Industrial">Industrial(50%)</option>
			    </select>

			    <label for="location">Location:</label>
			    <select id="location" name="location" required>
			        <option value="City">City(2%)</option>
			        <option value="Municipality">Municipality(2%)</option>
			        <option value="Province">Province(1%)</option>
			    </select>

			    <button class="btn" type="button" onclick="calculateTax()">Calculate Tax</button>

			    <label for="assessedValue">Assessed Value</label>
			    <input type="text" id="assessedValue" name="assessedValue" placeholder="Assessed Value" readonly>

			    <label for="basicTax">Basic RPT</label>
			    <input type="text" id="basicTax" name="basicTax" placeholder="Basic RPT" readonly>

			    <label for="sef">Special Education Fund(1%)</label>
			    <input type="text" id="sef" name="sef" placeholder="Special Education Fund(1%)" readonly>

			    <label for="totalTax">Total Tax Amount</label>
			    <input type="text" id="totalTax" name="totalTax" placeholder="Total Tax Amount" readonly>

			    <span class="errors">
					<?php echo $errors["error"]; ?>
				</span>

			    <button class="btn" type="submit">Save</button>
			</form>
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
	<script type="text/javascript">
	// Tax Calculations
	function calculateTax() {
	  const propertyValue = parseFloat(document.getElementById('propertyValue').value);
	  const propertyType = document.getElementById('propertyType').value;
	  const location = document.getElementById('location').value;

	  const assessmentLevels = {
	    'Residential': {'City': 20, 'Municipality': 20, 'Province': 20},
	    'Commercial': {'City': 50, 'Municipality': 50, 'Province': 50},
	    'Agricultural': {'City': 40, 'Municipality': 40, 'Province': 40},
	    'Industrial': {'City': 50, 'Municipality': 50, 'Province': 50}
	  };

	  const taxRates = {'City': 0.02, 'Municipality': 0.02, 'Province': 0.01};
	  const sefRate = 0.01; // SEF rate is 1%

	  const assessmentLevel = assessmentLevels[propertyType][location];
	  const assessedValue = propertyValue * (assessmentLevel / 100);
	  const taxRate = taxRates[location];
	  const basicTax = assessedValue * taxRate;
	  const sefAmount = assessedValue * sefRate;
	  const totalTax = basicTax + sefAmount;

	  document.getElementById('assessedValue').value = assessedValue.toFixed(2);
	  document.getElementById('basicTax').value = basicTax.toFixed(2);
	  document.getElementById('sef').value = sefAmount.toFixed(2);
	  document.getElementById('totalTax').value = totalTax.toFixed(2);
	}

	</script>
</body>
</html>



	