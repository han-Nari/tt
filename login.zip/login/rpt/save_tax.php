<?php 
$errors = array("error" => "");
if($_SERVER["REQUEST_METHOD"] === "POST") {
	$assessedValue = $_POST['assessedValue'];
	$basicTax = $_POST['basicTax'];
	$sef = $_POST['sef'];
	$totalTax = $_POST['totalTax'];

	if(empty($assessedValue) && empty($basicTax) && empty($sef) && empty($totalTax)) {
		$errors["error"] = "Please fill up the form properly!";
	}

	if(array_filter($errors)) {
		// Error
	} else {
		// SQL to insert data into database
		$query = "INSERT INTO tax (assessed_value, basic_tax, sef, total_tax) VALUES(:assessed_value, :basic_tax, :sef, :total_tax)";
		$stmt = $pdo->prepare($query);
		$stmt->bindParam(":assessed_value", $assessedValue);
		$stmt->bindParam(":basic_tax", $basicTax);
		$stmt->bindParam(":sef", $sef);
		$stmt->bindParam(":total_tax", $totalTax);
		$stmt->execute();
		if($stmt) {
			$_SESSION['success_message'] = "Record created successfully";
			header("location: tax.php");
			exit();
		}
	}

}